Status: in development

This QGIS plugin can be used to fetch data from the Eurostat API.